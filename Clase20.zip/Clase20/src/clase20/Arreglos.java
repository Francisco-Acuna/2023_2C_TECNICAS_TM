

package clase20;


public class Arreglos {
    public static void main(String[] args) {
        
        //Si tuvi�ramos que guardar varios n�meros en variables:
        int variable1 = 456;
        int variable2 = 34;
        int variable3 = 98;
        
        /*
        Podemos generar un conjunto de variables que tenga un mismo
        nombre que las agrupe a todas.
        Se puede acceder a cada variable por medio del �ndice.
        El �ndice comienza en 0.
        Con esto logramos optimizar la lectura de la informaci�n para
        acceder por un mismo nombre a distintas variables, y no por 
        el nombre de cada una.
        */
        
        System.out.println("** Arreglos, vectores o Arrays **");
        
        /*
        DECLARACI�N:
        tipoDeDato[] indentificador; --> declaraci�n
        tipoDeDato identificador[]; --> declaraci�n
        identificador = new tipoDeDato[n]; --> cantidad de variables que tendr�
        */
        
        float[] temperaturas; //declaraci�n de arreglo
        temperaturas = new float[10]; //definici�n de la longitud
        float temperaturas2[];
        temperaturas2 = new float[12];
        String[] nombres = new String[5]; //declaraci�n y definici�n
        //de longitud en l�nea.
        
        //asignaci�n de valores a las variables de un arreglo
        temperaturas[0] = 25.32f;
        temperaturas[1] = 12.56f;
        temperaturas[2] = 23.12f;
        temperaturas[3] = 36.12f;
        
        //temperaturas[4] = "Jose"; error, la variable no es del mismo tipo
        
        nombres[0] = "Juan";
        nombres[1] = "Mariana";
//        nombres[5] = "Jorge"; error, no existe el sub�ndice 5

        
        //leer el contenido de un sub�ndice:
        System.out.println(temperaturas[2]);
        System.out.println(nombres[1]);
        System.out.println(nombres[4]);
        //System.out.println(nombres[6]); error, no existe esa posici�n
        
        //inicializaci�n
        int[] numeros = {12, 59, 87, 129, 0};
             //posici�n   0   1   2    3  4  
        //en este caso, declaramos e inicializamos un vector de enteros
        //con 5 posiciones.
        
        //mostrar el contenido de un arreglo:
        System.out.println(numeros); // no muestra el contenido
        //muestra la posici�n de memoria del vector en formato
        //hexadecimal. Porque el nombre del vector es una referencia,
        //no es el contenido.
        
        //entonces, para mostrar el contenido:
        System.out.println("Contenido del arreglo:");
        System.out.println(numeros[0]);
        System.out.println(numeros[1]);
        System.out.println(numeros[2]);
        System.out.println(numeros[3]);
        System.out.println(numeros[4]);
        
        System.out.println("\nRecorrido con un contador o referencia");
        int contador = 0;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        contador++;
        System.out.println(numeros[contador]);
        
        //recorrido con for
        System.out.println("\nRecorrido con for");
        for(int i=0; i<5;i++){
            System.out.println(numeros[i]);
        }
        
        System.out.println("\nRecorrido con for, mostrando el �ndice");
        for(int i=0;i<5;i++){
            System.out.println("El contenido del vector en la posici�n "
                    + i + " es "+ numeros[i]);
        }
        
    }
}
