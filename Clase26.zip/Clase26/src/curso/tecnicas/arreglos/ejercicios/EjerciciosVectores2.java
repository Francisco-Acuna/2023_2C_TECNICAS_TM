

package curso.tecnicas.arreglos.ejercicios;

import java.util.Scanner;


public class EjerciciosVectores2 {
    public static void main(String[] args) {
        /*
        Ejercicio:
        Crear un vector de enteros de 10 posiciones
        Pedirle al usuario que cargue 10 valores para ese vector
        Mostrar con foreach el listado de n�meros que ingres�.
        Mostrar la suma de todos los elementos
        Mostrar el promedio
        Indicar cu�ntos n�meros pares y cu�ntos impares hay
        Indicar cu�ntas veces se repiti� el n�mero 2
        Resolver todo dentro de un m�todo que sea invocado dentro del main.
        */
        
        resolverEjercicio();
    }
    
    public static void resolverEjercicio(){
        int[] arreglo = crearArregloDe10Posiciones();
        System.out.println("Los n�meros ingresados son:");
        for(int a:arreglo) System.out.print(a+" ");
        System.out.println("\nLa suma total de todos los elementos del arreglo "
                + "es de: "+sumarTodosLosElementosDelArreglo(arreglo));
        System.out.println("El promedio del arreglo es: "+obtenerPromedioDelArreglo(arreglo));
        cantidadDeParesEImpares(arreglo);
        System.out.println("El n�mero 2 aparece "+cantidadDeRepeticionesNumero(arreglo, 2)+" veces");
    }
    
    
    public static int[] crearArregloDe10Posiciones(){
        Scanner teclado = new Scanner(System.in);
        int[] arreglo = new int[10];
        System.out.println("Por favor ingrese cada uno de los valores y presione enter:");
        for(int i=0; i<arreglo.length; i++){
            arreglo[i] = teclado.nextInt();
        }
        return arreglo;
    }
    
    public static int sumarTodosLosElementosDelArreglo(int[] arreglo){
        int suma = 0;
        for(int a:arreglo) suma+=a;
        return suma;
    }
    
    public static double obtenerPromedioDelArreglo(int[] arreglo){
        double promedio =  sumarTodosLosElementosDelArreglo(arreglo) / arreglo.length;
        return promedio;
    }
    
    public static void cantidadDeParesEImpares(int[] arreglo){
        int cantidadDePares = 0;
        int cantidadDeImpares = 0;
        for(int a:arreglo){
            if(a%2==0) cantidadDePares++;
            else cantidadDeImpares++;
        }
        System.out.println("El arreglo tiene "+cantidadDePares+" n�meros pares y "
                + cantidadDeImpares+" n�meros impares");
    }
    
    public static int cantidadDeRepeticionesNumero(int[] arreglo, int numero){
        int cantidadDeRepeticiones = 0;
        for(int a:arreglo) if(a == numero) cantidadDeRepeticiones++;
        return cantidadDeRepeticiones;
    }
}
