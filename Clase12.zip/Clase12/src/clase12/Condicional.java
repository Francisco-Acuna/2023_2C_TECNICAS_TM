

package clase12;


public class Condicional {
    public static void main(String[] args) {
        //Condicionales
        
        //Estructura if
        System.out.println("**Estructura if**");
        
        int nro1 = 20;
        int nro2 = 10;
        
        /*
        estructura:
        if(){ -> en esta línea va la condición a evaluar, dentro de los paréntesis
            acá van las sentencias, dentro del cuerpo del if
        } esta llave indica el final de la estructura del if
        aquí continúa el resto del programa
        */
        
        if(nro1 > nro2){
            System.out.println("El primer número es mayor que el segundo");
        }
        System.out.println("Fin de la estructura if");
        
        if(nro1 == nro2){
            System.out.println("Ambos números son iguales");
        }
        
        if (nro1 != nro2) {
            System.out.println("Ambos números son distintos");
        }
        
        
        
        
        
        
    }
}
