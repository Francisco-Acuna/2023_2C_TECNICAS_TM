
package clase02;

public class Clase02 {

    public static void main(String[] args) {
        //Variables
        int a; //declarando una variable
        a = 2; //asignando valor a la variable
        a = 4; //cambiamos el valor de la variable
        //a = "hola"; error porque no puedo ponerle otro tipo de dato como valor
        
        //una variable tiene una única declaración
        //y puede tener innumerables valores
        //pero siempre tiene que ser del mismo tipo de dato
        
        int c=12, d=32, e=41; //declaración y asigancíon múltiple
        
        //Tipos de datos primitivos
        
        //byte - ocupa 1 byte y representa un entero 
        //entre -128 y 127
        byte f = 100;
        System.out.println(f);
        
        //short - ocupa 2 bytes y representa un entero
        //entre -32.768 y 32.767
        //short g =32768; error, no alcanza a representar ese número
        short g = 32767;
        System.out.println(g);
        
        //int - ocupa 4 bytes y representa un entero
        //entre -2.147.483.648 y 2.147.483.647
        int h = -2130000325;
        System.out.println(h);
        
        //long - ocupa 8 bytes y representa un entero
        //número demasiado grande no tan utilizado
        long i = 33222555999L; //debemos colocar una L al final
        //por convención usamos la mayúscula
        System.out.println(i);
        
        //float - ocupa 4 bytes y tiene una precisión de 32 bits
        float j = 23.14f; //debemos escribir una f al final
        //el . separa los decimales. No usamos la coma (,)
        System.out.println(j);
        
        //double - ocupa 8 bytes y tiene una precisión de 64 bits
        double k = 33.45; //no hace falta agregarle una letra al final
        System.out.println(k);
        
        //diferencia entre float y double
        float fl = 10f;
        double dl = 10;
        System.out.println(fl / 3);
        System.out.println(dl / 3);
        
        //boolean - ocupa 1 byte y almacena sólo 2 valores
        //true y false
        boolean l = true; //asigna un valor que representa "verdad"
        boolean m = false; //asigna un valor que representa "falso"
        System.out.println(l);
        System.out.println(m);
        
        //char - ocupa 2 bytes y almacena un entero
        //representa un caracter de la tabla unicode
        char n = 65; //se almacena como un entero
        //pero representa un caracter
        System.out.println(n);
        n += 32; //le sumo 32 a la variable y la paso a minúscula
        System.out.println(n);
        //también podemos guardar el caracter directamente
        n = 'f'; //el caracter deber ir entre comillas simples
        System.out.println(n);
        
        //String - no es un tipo de dato primivo
        //representa una cadena de caracteres
        String o = "Hola"; //al ser una clase, debe comenzar en mayúscula
        //el valor asignado debe ir entre comillas dobles ""
        String p = "Hola, soy una cadena de caracteres. @ 44";
        System.out.println(o);
        System.out.println(p);
        
        
    }
    
}
