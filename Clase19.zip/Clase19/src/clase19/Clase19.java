
package clase19;

import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase19 {

    public static void main(String[] args) {
        System.out.println("*** Funciones y Procedimientos ***");
        
        /*
        Las funciones y procedimientos son un bloque de c�digo que contienen
        una o m�s instrucciones, al cual podemos invocar para que sean 
        ejecutadas. Las funciones y los procedimientos nos van a ayudar a
        hacer nuestro c�digo m�s legible y evitar c�digo duplicado.
        */
        
        System.out.println("** Funciones **");
        /*
        Los m�todos de tipo funci�n siempre retornan un valor. 
        En su declaraci�n deben indicar qu� tipo de valor retornan.
        En su cuerpo debe contener la sentencia 'return' con el retorno
        del tipo de dato que se indic� en su cabecera.
        */
        
        int numero1 = retornarNumeroDiez(); //llamar o invocar al m�todo
        System.out.println(numero1);
        System.out.println(retornarNumeroDiez());
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Por favor ingrese un n�mero entero:");
        int primerNumero = teclado.nextInt();
        System.out.println("Por favor ingrese otro n�mero entero:");
        int segundoNumero = teclado.nextInt();
        
        System.out.println("La suma de los dos n�meros enteros ingresados es de: ");
        System.out.println(sumarDosEnteros(primerNumero, segundoNumero));
        
    } // final del m�todo main
    
    //ejemplos de funciones
    public static int retornarNumeroDiez(){
        return 10; // el return debe retornar el mismo tipo de dato
        //declarado en la firma del m�todo
    }
    
    public static int sumarDosEnteros(int num1, int num2){
        return num1 + num2;
    }
    
} // final de la clase
