
package clase21;

import java.util.Scanner;

/**
 *
 * @author Aula 8 - Docente
 */
public class FuncionesProcedimientos {

    public static void main(String[] args) {
        System.out.println("*** Funciones y Procedimientos ***");
        
        /*
        Las funciones y procedimientos son un bloque de c�digo que contienen
        una o m�s instrucciones, al cual podemos invocar para que sean 
        ejecutadas. Las funciones y los procedimientos nos van a ayudar a
        hacer nuestro c�digo m�s legible y evitar c�digo duplicado.
        */
        
        System.out.println("** Funciones **");
        /*
        Los m�todos de tipo funci�n siempre retornan un valor. 
        En su declaraci�n deben indicar qu� tipo de valor retornan.
        En su cuerpo debe contener la sentencia 'return' con el retorno
        del tipo de dato que se indic� en su cabecera.
        */
        
        int numero1 = retornarNumeroDiez(); //llamar o invocar al m�todo
        System.out.println(numero1);
        System.out.println(retornarNumeroDiez());
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Por favor ingrese un n�mero entero:");
        int primerNumero = teclado.nextInt();
        System.out.println("Por favor ingrese otro n�mero entero:");
        int segundoNumero = teclado.nextInt();
        teclado.nextLine();
        
        System.out.println("La suma de los dos n�meros enteros ingresados es de: ");
        System.out.println(sumarDosEnteros(primerNumero, segundoNumero));
        
        System.out.println(esPar(13));
        
        int suma = 2 + 3;
        System.out.println(suma);
        
        System.out.println("** Procedimientos **");
        /*
        Los m�todos de tipo procedimiento, no tienen un retorno.
        En su declaraci�n deben tener la palabra reservada void,
        para indicar que no tienen retorno.
        */
        
        saludar();
        
        saludarConNombre("Sol");
        
        String usuario = "Pepito";
        saludarConNombre(usuario);
        
        System.out.println("Ingrese su usuario:");
        saludarConNombre(teclado.nextLine());
        
        calcularAreaRectangulo(18, 23.56f);
        calcularAreaRectangulo(25.4f, 78.2f);
        
        float baseRectangulo = 12.25f;
        float alturaRectangulo = 32.47f;
        calcularAreaRectangulo(baseRectangulo, alturaRectangulo);
        
        sumarParImpar(primerNumero, segundoNumero, "Carla");
        
        /*
        Crear un programa que tenga un m�todo al cual se le ingrese una frase como
        par�metro y luego imprima por consola la misma frase repetida 7 veces.
        */
        
        /*
        Crear un programa que reciba 3 par�metros y calcule la suma, resta, nmultiplicaci�n,
        divisi�n y el resto de dos n�meros con decimales.
        Las consignas para lograrlo son:
        * Se debe crear un m�todo que no retorne nada, que reciba los 3 par�metros. 2 n�meros
        con decimales y el caracter de la operaci�n.
        * Se deben crear los m�todos de las operaciones que retorne un n�mero con decimales
        * Se debe mostrar por consola un mensaje que indique el resultado y la operaci�n realizada.
        */
        
    } // final del m�todo main
    
    //ejemplos de funciones
    public static int retornarNumeroDiez(){
        return 10; // el return debe retornar el mismo tipo de dato
        //declarado en la firma del m�todo
    }
    
    //este m�todo nos pide dos par�metros
    //los par�metros son los valores de entrada
    //se escriben indicando primero el tipo de dato y luego su nombre
    //el nombre se utiliza para hacer una referencia, no hace falta
    //que se llamen igual al momento de usar el m�todo.
    public static int sumarDosEnteros(int num1, int num2){
        return num1 + num2;
    }
    
    /**
     * Este m�todo indica si el n�mero entero pasado como par�metro es par.
     * @param numero
     * @return boolean
     */
    public static boolean esPar(int numero){
//        if(numero%2 == 0) {
//            return true;
//        }else{
//            return false;
//        }
        return numero%2 == 0;
        //no hace falta un if-else. La operaci�n ya me devuelve un booleano.
    }
    
    //Procedimientos
    public static void saludar(){
        System.out.println("Hola Mundo!!");
    }
        
    public static void saludarConNombre(String nombre){
        System.out.println("Hola "+nombre+"!!");
    }
    
     public static void calcularAreaRectangulo(float base, float altura){
         float area = base * altura;
         System.out.println("El �rea del rect�ngulo es: "+area);
     }
     
     //Ejemplo de m�todos dentro de m�todos
     public static void sumarParImpar(int numero1, int numero2, String nombre){
         saludarConNombre(nombre);
         if(esPar(sumarDosEnteros(numero1, numero2))){
             System.out.println("La suma es par!!");
         }else {
             System.out.println("La suma es impar");
         }
     }
        
    
} // final de la clase
