

package clase21;

import java.util.Scanner;


public class Ejercicios {
    public static void main(String[] args) {
         /*
        Crear un programa que tenga un m�todo al cual se le ingrese una frase como
        par�metro y luego imprima por consola la misma frase repetida 7 veces.
        */
         Scanner teclado = new Scanner(System.in);
         
         System.out.println("Ingrese una frase aleatoria. La misma se repetir� 7 veces:");
         String frase = teclado.nextLine();
         ejercicioFrase(frase);
         
         /*
        Crear un programa que reciba 3 par�metros y calcule la suma, resta, nmultiplicaci�n,
        divisi�n y el resto de dos n�meros con decimales.
        Las consignas para lograrlo son:
        * Se debe crear un m�todo que no retorne nada, que reciba los 3 par�metros. 2 n�meros
        con decimales y el caracter de la operaci�n.
        * Se deben crear los m�todos de las operaciones que retorne un n�mero con decimales
        * Se debe mostrar por consola un mensaje que indique el resultado y la operaci�n realizada.
        */
         System.out.println("Ingrese dos n�meros e indique el operador para realizar el c�lculo");
         System.out.println("A continuaci�n ingrese el primer n�mero y presione enter:");
         double numero1 = teclado.nextDouble();
         System.out.println("Ahora ingrese el segundo n�mero y presione enter:");
         double numero2 = teclado.nextDouble();
         System.out.println("Ingrese el caracter de la operaci�n que quiere realizar:");
         String operador = teclado.next();
         
         ejercicioOperacion(numero1, numero2, operador);
         
    } // final m�todo main
    
    public static void ejercicioFrase(String frase){
        for (int i=1; i<=7; i++) {
            System.out.println(i+"- "+frase);
        }
    }//final m�todo ejercicioFrase
    
    public static void ejercicioOperacion(double numero1, double numero2, String operacion){
        switch(operacion){
            case "+": System.out.println(sumar(numero1, numero2)); break;
            case "-": System.out.println(restar(numero1, numero2));break;
            case "*": System.out.println(multiplicar(numero1, numero2)); break;
            case "/":
                if(numero2==0){
                    System.out.println("No se puede dividir por 0");
                 break;
                }else {
                    System.out.println(dividir(numero1, numero2));
                    break;
                }
            case "%": System.out.println(obtnerResto(numero1, numero2)); break;
            default: System.out.println("El caracter ingresado "
                    + "no corresponde a ninguna operaci�n v�lida.");
        }
    }
    
    public static double sumar(double num1, double num2){
        System.out.println("La operaci�n elegida fue la suma.\nY este es el resultado:");
        return num1 + num2;
    }
    
    public static double restar(double num1, double num2){
        System.out.println("La operaci�n elegida fue la resta.\nY este es el resultado:");
        return num1 - num2;
    }
    
    public static double multiplicar(double num1, double num2){
        System.out.println("La operaci�n elegida fue la multiplicaci�n.\nY este es el resultado:");
        return num1 * num2;
    }
    
    public static double dividir(double num1, double num2){
        System.out.println("La operaci�n elegida fue la divisi�n.\nY este es el resultado:");
        return num1 / num2;
    }
    
    public static double obtnerResto(double num1, double num2){
        System.out.println("La operaci�n elegida fue el resto.\nY este es el resultado:");
        return num1 % num2;
    }
    
} // final clase
