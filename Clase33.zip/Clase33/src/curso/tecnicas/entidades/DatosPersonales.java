

package curso.tecnicas.entidades;


public class DatosPersonales {
    public static String nombre;
    public static String apellido;
    public static String dni;
    public static String telefono;
    public static String email;
}
