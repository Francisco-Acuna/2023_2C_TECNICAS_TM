

package curso.tecnicas.entidades;


public class CalculadoraLogica {
    public static double calcular(double numero1, double numero2, char operador){
        double resultado = 0;
        switch(operador){
            case '+': resultado = numero1 + numero2; break;
            case '-': resultado = numero1 - numero2; break;
            case '*': resultado = numero1 * numero2; break;
            case '/': resultado = numero1 / numero2; break;
        }
        return resultado;
    }
}
