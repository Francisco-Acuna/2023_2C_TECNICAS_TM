/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase07;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase07 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        Dados n1=10, n2=20, n3=30. Informar:
        a) el total
        b) el promedio
        c) el resto entre n2 y n1
        */
        
        int n1 = 10;
        int n2 = 20;
        int n3 = 30;
        
        int total = n1 + n2 +n3;
        System.out.println("El total es " + total);
        double promedio =  total / 3;
        System.out.println("El promedio es " + promedio);
        int resto = n2 % n1;
        System.out.println("El resto entre n2 y n1 es " + resto);
        
        /*
        Declarar dos variables n1=5 y n2=10.
        Utilizando concatenación entre las variables y los literales, 
        mostrar en pantalla la siguiente expresión:
        n1 es igual a 5, n2 es igual a 10 y n1 más n2 es igual a 15.
        */
        
        n1 = 5;
        n2 = 10;
        total = n1 + n2;
        
        System.out.println("n1 es igual a " + n1 + ", n2 es igual a " + n2 +
                " y n1 más n2 es igual a " + total + ".");
        
        /*
        Haciendo uso de la constante IVA=21,calcular el precio con IVA 
        de los siguientes productos e informar:
        a) remera:$59.90
        b) pantalón:$99.90
        c) campera:$149.90
        */
        
        final int IVA = 21;
        double remera = 59.90;
        double remeraConIva = (remera / 100) * IVA + remera;
        System.out.println("El valor de la remera con IVA es: $" + remeraConIva);
        
        
    }
    
}
