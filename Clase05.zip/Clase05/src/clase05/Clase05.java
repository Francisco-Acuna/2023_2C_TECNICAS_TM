/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase05;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        //método para extraer una subcadena
        String palabra = "Programación";
        //String es una clase que representa una cadena de caracteres
        //cada caracter ocupa un lugar de posición
        //las posiciones comienzan desde la nro 0
        String subPalabra = palabra.substring(3);
        //el número que va entre paréntesis es la posición desde donde 
        //comenzará la subcadena
        System.out.println(subPalabra);
        System.out.println(palabra);
        //si pasamos 2 parámetros al método, le estamos indicando
        //desde dónde y hasta dónde queremos la subcadena
        String subPalabra2 = palabra.substring(5, 8);
        System.out.println(subPalabra2);

        String palabra1 = "cuesta";
        String palabra2 = "subir";
        String palabra3 = "la";
        String palabra4 = "a";
        String palabra5 = "e";
        String palabra6 = "l";
        String palabra7 = "v";
        String palabra8 = "s";
        String palabra9 = "n";
        String palabra10 = "d";
        String palabra11 = "y";
        String palabra12 = "medio";
        
        System.out.println(palabra4.toUpperCase()+ " " +
                palabra1.substring(0,1).toUpperCase() + palabra1.substring(1));

        //Operadores de asignación
        /*
        = igual (asignación)
        += suma y asignación
        -= resta y asignación
        *= multiplicación y asignación
        /= división y asignación
        %= módulo y asignación
        Son operadores binarios porque necesitan 2 operandos.
        Asignan el valor a una variable y se la modifican utilizando una expresión
        */
        
        int nro1 = 10;
        int nro2 = 2;
        
        System.out.println(nro1); //nro1 vale 10
        nro1 = 12; //con el = se le asigna el valor que está a la derecha
        System.out.println(nro1); //ahora vale 12
        
        nro1 += 2; //con el += le estamos sumando 2 al valor de la variable
        //es lo mismo que hacer: nro1 = nro1 + 2;
        System.out.println(nro1); //ahora vale 14
        
        nro1 -= 2; //con el -= le estamos restando 2 al valor de la variable
        //es lo mismo que hacer: nro1 = nro1 - 2;
        System.out.println(nro1);
        
        nro1 *= 2; //multiplica el valor de la variable por 2
        //es lo mismo que hacer: nro1 = nro1 * 2;
        System.out.println(nro1); //ahora vale 24
        
        nro1 /= 2; //divide el valor de la variable por 2
        //es lo mismo que hacer: nro1 = nro1 / 2;
        System.out.println(nro1); //ahora vale 12
        
        nro1 %= 2; //le asigna a la variable el resto de la división entre nro1 y el 2
        System.out.println(nro1); //ahora vale 0   
        
        
        //Operadores incrementales y decrementales
        /*
        ++ incremento en 1
        -- decremento en 1
        Son operadores unarios, trabajan con un solo operador.
        */
        
        nro1 ++; //valía 0 y ahora vale 1
        //es lo mismo que: nro1 = nro1 + 1;
        //también es lo mismo que: nro1 += 1;
        System.out.println(nro1);
        
        nro1 --; //valía 1 y ahora vale 0
        //es lo mismo que: nro1 = nro1 -1;
        //también es lo mismo que: nro1 -=1;
        System.out.println(nro1);
        
        //Operadores relacionales
        /*
        > mayor
        < menor
        >= mayor o igual
        <= menor o igual
        == igual
        != distinto
        Son operadores binarios.
        Los operandos son numéricos y el resultado es booleano
        */
        
        nro1 = 15;
        nro2 = 20;
        
        System.out.println(nro1 > nro2); //false
        System.out.println(nro1 < nro2); //true
        System.out.println(nro1 >= nro2); //false
        System.out.println(nro1 <= nro2); //true
        System.out.println(nro1 == nro2); //false  está comparando con ==
        System.out.println(nro1 != nro2); //true
        
        
        
    }

}
