

package clase24;

import java.util.Scanner;


public class EjerciciosVectores {
    public static void main(String[] args) {
        /*
        Ejercicio:
        Crear un vector de enteros de 10 posiciones
        Pedirle al usuario que cargue 10 valores para ese vector
        Mostrar con foreach el listado de n�meros que ingres�.
        Mostrar la suma de todos los elementos
        Mostrar el promedio
        Indicar cu�ntos n�meros pares y cu�ntos impares hay
        Indicar cu�ntas veces se repiti� el n�mero 2
        Resolver todo dentro de un m�todo que sea invocado dentro del main.
        */
        
        /*
        Ejercicio2:
        Crear un vector que contenga el monto de la facturaci�n total de
        una empresa durante un a�o (de enero a diciembre).
        Informar:
        - la m�xima facturaci�n
        - la facturaci�n m�s baja
        - el promedio de facturaci�n
        */
        
        
    }
    
    public static double[] crearArreglo(){
        Scanner teclado = new Scanner(System.in);
        double[] vector = new double[12];
        System.out.println("Ingrese los 12 valores correspondientes a la facturaci�n:");
        for(int i=0; i<vector.length; i++){
            vector[i] = teclado.nextDouble();
        }
        return vector;
    }
}
