/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase08;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase08 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Clase String
        
        System.out.println("** Clase String **");
        //la clase String contiene un vector de caracteres
        
        //podemos crear un objeto de la clase String de varias maneras:
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("hola");
        String texto3 = "hola";
        
        //métodos para comparar
        //al comparar con el operador == va a comparar que 
        //sean el mismo objeto en memoria
        System.out.println(texto2 == "hola"); //false
        //no se utiliza el == para comparar cadenas de caracteres
        
        //para poder comparar cadenas de caracteres teniendo en cuenta 
        //su contenido, se utilizan los siguientes métodos:
        //.equals()  .equalsIgnoreCase()
        System.out.println(texto2.equals("hola")); //true
        //.equals() compara literalmente las cadenas
        System.out.println(texto2.equals("HOLA")); //false
        //.equalsIgnoreCase() ignora las minúsculas y mayúsculas
        System.out.println(texto2.equalsIgnoreCase("HOLA")); //true
        
        //.contains()
        //devuelve un booleano si contiene la subcadena dada
        System.out.println(texto1.contains("hola")); //false
        System.out.println(texto2.contains("hola")); //true
        
        //.length()
        //devuelve la longitud del vector, es decir, cuántos caracteres tiene
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4
        
        //.isEmpty()
        //indica si la cadena está vacía, es decir, si su longitud es igual a 0
        System.out.println(texto1.isEmpty()); //false
        
        //.isBlank() aparece a partir de JDK 11
        //indica si una cadena está vacía, en blanco o consiste únicamente de espacios
        //en blanco, como por ejemplo si sólo contiene espacios, tabulaciones
        // y/o saltos de línea
        String texto4 = "      ";
        System.out.println(texto4.isEmpty()); //da false porque no la toma como vacía
        System.out.println(texto4.isBlank()); //da true porque la toma como vacía
        
        //.charAt()
        //devuelve el caracter del índice indicado
        System.out.println(texto1.charAt(5));
        System.out.println(texto2.charAt(2));
        
        //.indexOf()
        //devuelve el índice de la primera ocurrencia de la subcadena
        //si no encuentra la subcadena, devuelve -1
        System.out.println(texto1.indexOf("texto")); //-1
        //no la encontró porque la t es mayúscula
        System.out.println(texto1.indexOf("Texto")); //10
        
        //.trim()
        //quita los espacios de adelante y de atrás
        texto3 = "   buenas noches   ";
        System.out.println(texto3);
        System.out.println(texto3.trim());
        
        //.startsWith()  .endsWith()
        //devuelve un booleano si la cadena comienza o termina con el texto dado
        System.out.println(texto1.startsWith("hol")); //false
        System.out.println(texto2.startsWith("hol")); //true
        System.out.println(texto1.endsWith("exto")); //false
        System.out.println(texto1.endsWith("exto!")); //true
        
        
        //métodos para reemplazar
        //.replace()
        //remplaza un caracter por otro
        System.out.println(texto1.replace('e', 'i'));
        //reemplaza una cadena de caracteres por otra
        System.out.println(texto1.replace("Texto", "caracteres"));
        //reemplazar sólo la primera vez que aparezca la cadena
        texto3 = "manzana, manzana, naranja";
        System.out.println(texto3.replaceFirst("manzana", "banana"));
        //reemplazar todas las veces que aparezca la cadena
        System.out.println(texto3.replaceAll("manzana", "banana"));
        //si bien replace() también reemplaza todas las veces que aparezca
        //la subcadena, el replaceAll() es más potente.
        //Nos permite buscar y reemplazar patrones de expresiones regulares
        //Una expresión regular es una secuencia de caracteres que definen
        //un patrón de búsqueda.
        //En Java son regex o regexp
        String texto5 = "Mi número de teléfono es 011-8888-9999 "
                + "y mi otro número es 365-1010-2727";
        System.out.println(texto5.replaceAll("\\d{3}-\\d{4}-\\d{4}", "TELÉFONO"));
        //en este ejemplo utilizamos un patrón de expresión regular que busca
        //todas las ocurrencias de una cadena de caracteres que coincida con
        //el formato ###-####-####
        
        //.repeat() a partir de JDK 11
        //repite la cadena la cantidad de veces que se indique
        System.out.println(texto2.repeat(3));
        
        //anteriormente ya hemos visto 
        //.toUppercase() .toLowerCase() .substring()
        
        //caracteres de escape
        //son secuencias especiales de caracteres que se utilizan en cadenas
        //de texto y literales de caracteres para representar caracteres especiales
        //o caracteres que no se pueden representar directamente.
        //Los caracteres de escape comienzan con una barra invertida (\) seguida 
        //de un caracter que indica que tipo de escape se está utilizando
        
        //algunos ejemplos:
        
        // \n salto de línea
        System.out.println("Hola\nMundo!");
        
        // \t tabulación
        System.out.println("Hola\tMundo!");
        
        // \" comillas dobles
        System.out.println("\"Hola Mundo!\"");
        
        // \' comillas simples
        System.out.println("\'Hola Mundo!\'");
        
        // \\ barra invertida
        System.out.println("\\Hola Mundo!\\");
        
        
    }
    
}
