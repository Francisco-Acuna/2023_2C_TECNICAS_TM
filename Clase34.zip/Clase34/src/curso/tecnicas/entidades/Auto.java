

package curso.tecnicas.entidades;


public class Auto {
    //Atributos
    //los atributos o propiedades son las caracter�sticas
    //representa lo que tiene, y son variables
    public String marca;
    public String modelo;
    public String color;
    public int velocidad;
    
    
    //constructores
    //es el m�todo que se utiliza para poder crear un objeto de la clase
    public Auto(){}
    
    //sobrecarga de constructores
    public Auto(String marca, String modelo, String color, int velocidad) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = velocidad;
    }

    public Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }

    /**
     * Este constructor es para crear autos de la marca Ford
     * @param modelo
     * @param color 
     */
    public Auto(String modelo, String color) {
        this.marca = "Ford";
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }
    
    //m�todos de la clase
    //son las acciones que puede realizar
    public void acelerar(){
        velocidad += 10;
    }
    
    public void frenar(){
        velocidad -= 10;
    }
    
    //sobrecarga de m�todos
    public void acelerar(int kilometros){
        velocidad += kilometros;
    }
    
    /**
     * Este m�todo acelerar pide un segundo par�metro, que de ser verdadero,
     * incrementa el doble de kil�metros pasados por par�metro. 
     * De ser falso, s�lo incrementa los kil�metros pasados.
     * @param kilometros
     * @param turbo 
     */
    public void acelerar(int kilometros, boolean turbo){
        if(turbo) velocidad += kilometros*2;
        else velocidad += kilometros;        
    }

    @Override
    public String toString() {
        return "El auto es de la marca " + marca + ", modelo " + modelo + ", su color es " + color + ", y actualmente tiene una velocidad de " + velocidad + "Km/h";
    }

  
}
