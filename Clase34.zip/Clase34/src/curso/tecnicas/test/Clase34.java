
package curso.tecnicas.test;

import curso.tecnicas.entidades.Auto;

public class Clase34 {


    public static void main(String[] args) {
        Auto auto1 = new Auto();
        
        auto1.marca= "Ford";
        auto1.modelo = "Ka";
        auto1.color = "negro";
        auto1.velocidad = 0;
        
        System.out.println(auto1.marca);
        System.out.println(auto1.modelo);
        System.out.println(auto1.color);
        System.out.println(auto1.velocidad);
        
        System.out.println("***********************\n");
        
        Auto auto2 = new Auto("Peugeot", "206", "Celeste", 0);
        System.out.println(auto2.marca);
        System.out.println(auto2.modelo);
        System.out.println(auto2.color);
        System.out.println(auto2.velocidad);
        
        System.out.println("***********************\n");
        
        Auto auto3 = new Auto("Citroen", "C3", "Gris");
        
        System.out.println(auto3.marca);
        System.out.println(auto3.modelo);
        System.out.println(auto3.color);
        System.out.println(auto3.velocidad);
        
        
        System.out.println("***********************");
        
        Auto auto4 = new Auto("Fiesta", "Azul");
        
        System.out.println(auto4.marca);
        System.out.println(auto4.modelo);
        System.out.println(auto4.color);
        System.out.println(auto4.velocidad);
        
        
        System.out.println("***********************\n");   
        System.out.println(auto1.velocidad);
        auto1.acelerar();
        System.out.println(auto1.velocidad);
        for (int i = 0; i < 5; i++) {
            auto1.acelerar();
        }
        System.out.println(auto1.velocidad);
        
        auto1.frenar();
        System.out.println(auto1.velocidad);
        
        
        System.out.println("***********************\n"); 
        auto1.acelerar(150);
        System.out.println(auto1.velocidad);
        
        System.out.println("***********************\n"); 
        auto1.acelerar(100,false);
        System.out.println(auto1.velocidad);
        
        System.out.println(auto1.toString());
        System.out.println(auto1);
    }
    
    
    
}
