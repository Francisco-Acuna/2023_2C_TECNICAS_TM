/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase04;

/**
 *
 * @author Aula 8 - Docente
 */
public class Clase04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //String es una clase
        String nombre = "marcela";
        System.out.println(nombre);
        
        //Pasar texto a mayúsculas
        System.out.println(nombre.toUpperCase());
        System.out.println(nombre);
        nombre = nombre.toUpperCase();
        System.out.println(nombre);
        
        //Pasar texto a minúscula
        System.out.println(nombre.toLowerCase());
        System.out.println(nombre);
        nombre = nombre.toLowerCase();
        System.out.println(nombre);
        
        
        
        
    }
    
}
