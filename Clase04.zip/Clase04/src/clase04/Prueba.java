

package clase04;


public class Prueba {
    public static void main(String[] args) {
        String palabra1="cuesta";
        String palabra2="subir";
        String palabra3="la";
        String palabra4="a";
        String palabra5="e";
        String palabra6="l";
        String palabra7="v";
        String palabra8="s";
        String palabra9="n";
        String palabra10="d";
        String palabra11="y";
        String palabra12="medio";
        String palabra13=",";
       
       
       
        System.out.println(palabra4.toUpperCase()+" "+palabra1+" "+palabra6+palabra5+" "+palabra1+" "+palabra2+" "+palabra3+" "+palabra1+" "+palabra11+" "+palabra5+palabra9+" "+palabra12+" "+palabra10+palabra5+" "+palabra3+" "+palabra1+palabra13+" "+palabra7+palabra4+" "+palabra11+" "+palabra8+palabra5+" "+palabra4+palabra1);
    }

}
